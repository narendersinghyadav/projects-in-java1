package messanger;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.StringTokenizer;
import java.util.Vector;

public class chatserver {
	static Vector<Object> ClientSockets,LoginName;
	chatserver() throws IOException{
		@SuppressWarnings("resource")
		ServerSocket server =new ServerSocket(5217);
		ClientSockets =new Vector<Object>();
		LoginName=new Vector<Object>();
		while(true) {
			Socket client=server.accept();
			AcceptClient acceptClient=new AcceptClient(client);
		}
	}
	public static void main(String args[]) throws IOException {
		chatserver server=new chatserver();
	}
	class AcceptClient extends Thread{
		Socket ClientSocket;
		DataInputStream din;
		DataOutputStream dout;
		AcceptClient(Socket client) throws IOException{
			ClientSocket=client;
			din=new DataInputStream(ClientSocket.getInputStream());
			dout=new DataOutputStream(ClientSocket.getOutputStream());
			String LogInName=din.readUTF();
			LoginName.add(LogInName);
			ClientSockets.add(ClientSocket);
			start();
		}
		public void run() {
			while(true) {
					try {
						String messagefromClient=din.readUTF();
						StringTokenizer st=new StringTokenizer(messagefromClient);
						String LogInName=st.nextToken();
						String msgType=st.nextToken();
						String msg="";
						int lo=-1;
						while(st.hasMoreTokens()) {
							msg=msg+" " +st.nextToken();
						}
						if(msgType.equals("LOGIN")) {
						for(int i=0;i<LoginName.size();i++) {
							Socket pSocket=(Socket) ClientSockets.elementAt(i);
							DataOutputStream pout=new DataOutputStream(pSocket.getOutputStream());
							pout.writeUTF(LogInName+" has logged in. ");
						}
						}
						else if(msgType.equals("LOGOUT")) {
							for(int i=0;i<LoginName.size();i++) {
								if(LogInName.equals(LoginName.elementAt(i))) {
									lo=i;
								}
								Socket pSocket=(Socket) ClientSockets.elementAt(i);
								DataOutputStream pout=new DataOutputStream(pSocket.getOutputStream());
								pout.writeUTF(LogInName+" has logged out. ");
							}
							if(lo>=0) {
								LoginName.removeElementAt(lo);
								ClientSockets.removeElementAt(lo);
							}
							}
						else {
							for(int i=0;i<LoginName.size();i++) {
								Socket pSocket=(Socket) ClientSockets.elementAt(i);
								DataOutputStream pout=new DataOutputStream(pSocket.getOutputStream());
								pout.writeUTF(LogInName+" : "+msg);
								}
						}
						if(msgType.equals("LOGOUT"))
							break;
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
	}
}
